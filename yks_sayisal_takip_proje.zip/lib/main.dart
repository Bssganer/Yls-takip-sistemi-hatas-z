import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/study_models.dart';
import 'providers/app_providers.dart';
import 'services/notification_service.dart';
import 'services/settings_service.dart';
import 'ui/checklist_screen.dart';
import 'ui/end_of_day_wizard.dart';
import 'ui/home_screen.dart';
import 'ui/report_and_settings_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();
  Hive.registerAdapter(StudySessionAdapter());
  Hive.registerAdapter(TopicChecklistAdapter());

  await Hive.openBox<StudySession>('study_sessions');
  await Hive.openBox<TopicChecklist>('topic_checklists');

  final prefs = await SharedPreferences.getInstance();
  final settingsService = SettingsService(prefs);
  final initialGoal = settingsService.loadGoalSettings();

  final notificationService = NotificationService();
  await notificationService.init();
  await notificationService.scheduleDailyEndOfDayReminder(
    initialGoal.reminderHour,
    initialGoal.reminderMinute,
  );

  runApp(
    ProviderScope(
      overrides: [
        settingsServiceProvider.overrideWithValue(settingsService),
      ],
      child: const YksSayisalApp(),
    ),
  );
}

class YksSayisalApp extends StatelessWidget {
  const YksSayisalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'YKS Sayısal Takip',
      navigatorKey: NotificationService.navigatorKey,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const MainNavigationShell(),
    );
  }
}

class MainNavigationShell extends StatefulWidget {
  const MainNavigationShell({super.key});

  @override
  State<MainNavigationShell> createState() => _MainNavigationShellState();
}

class _MainNavigationShellState extends State<MainNavigationShell> {
  int _selectedIndex = 0;

  final List<Widget> _screens = const [
    HomeScreen(),
    ChecklistScreen(),
    ReportAndSettingsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    NotificationService().onNotificationTapped = () {
      final ctx = NotificationService.navigatorKey.currentContext;
      if (ctx != null) {
        showModalBottomSheet(
          context: ctx,
          isScrollControlled: true,
          useSafeArea: true,
          builder: (_) => const EndOfDayWizardModal(),
        );
      }
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (idx) => setState(() => _selectedIndex = idx),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard),
            label: 'Ana Sayfa',
          ),
          NavigationDestination(
            icon: Icon(Icons.checklist_rtl_outlined),
            selectedIcon: Icon(Icons.checklist_rtl),
            label: 'Konu Checklist',
          ),
          NavigationDestination(
            icon: Icon(Icons.picture_as_pdf_outlined),
            selectedIcon: Icon(Icons.picture_as_pdf),
            label: 'Rapor & Ayarlar',
          ),
        ],
      ),
    );
  }
}
