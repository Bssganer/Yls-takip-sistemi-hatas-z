import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/curriculum_data.dart';
import '../models/study_models.dart';
import '../providers/app_providers.dart';

class ChecklistScreen extends ConsumerStatefulWidget {
  const ChecklistScreen({super.key});

  @override
  ConsumerState<ChecklistScreen> createState() => _ChecklistScreenState();
}

class _ChecklistScreenState extends ConsumerState<ChecklistScreen> {
  String _selectedSubject = CurriculumData.allSubjects.first;

  @override
  Widget build(BuildContext context) {
    final checklistMap = ref.watch(checklistProvider);
    final allSessions = ref.watch(studySessionsProvider);
    final topics = CurriculumData.sayisalCurriculum[_selectedSubject] ?? [];

    final Map<String, int> topicDuration = {};
    final Map<String, int> topicQuestions = {};

    for (final s in allSessions) {
      if (s.sessionType == SessionType.topicStudy &&
          s.subject == _selectedSubject) {
        topicDuration[s.topic] =
            (topicDuration[s.topic] ?? 0) + s.durationMinutes;
        topicQuestions[s.topic] =
            (topicQuestions[s.topic] ?? 0) + s.totalQuestions;
      }
    }

    final completedCount = topics
        .where((t) => checklistMap['$_selectedSubject|$t']?.isCompleted ?? false)
        .length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('TYT & AYT Sayısal Müfredat Ağacı'),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 54,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              scrollDirection: Axis.horizontal,
              itemCount: CurriculumData.allSubjects.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final subj = CurriculumData.allSubjects[index];
                final isSelected = subj == _selectedSubject;
                return ChoiceChip(
                  label: Text(subj),
                  selected: isSelected,
                  onSelected: (_) => setState(() => _selectedSubject = subj),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _selectedSubject,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Text(
                  '$completedCount / ${topics.length} Konu Tamamlandı',
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, color: Colors.indigo),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView.builder(
              itemCount: topics.length,
              itemBuilder: (context, index) {
                final topic = topics[index];
                final keyId = '$_selectedSubject|$topic';
                final item = checklistMap[keyId];
                final isDone = item?.isCompleted ?? false;
                final isManualRed = item?.isManualRedList ?? false;
                final mins = topicDuration[topic] ?? 0;
                final qs = topicQuestions[topic] ?? 0;

                return ListTile(
                  leading: Checkbox(
                    value: isDone,
                    onChanged: (_) => ref
                        .read(checklistProvider.notifier)
                        .toggleCompleted(keyId),
                  ),
                  title: Text(
                    topic,
                    style: TextStyle(
                      decoration: isDone ? TextDecoration.lineThrough : null,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  subtitle: Text('Çözülen: $qs Soru  •  Çalışılan: $mins dk'),
                  trailing: IconButton(
                    tooltip: 'Kırmızı Listeye Ekle / Çıkar',
                    icon: Icon(
                      isManualRed ? Icons.flag : Icons.outlined_flag,
                      color: isManualRed ? Colors.red : Colors.grey,
                    ),
                    onPressed: () => ref
                        .read(checklistProvider.notifier)
                        .toggleManualRedList(keyId),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
