import 'package:hive/hive.dart';

enum RecordingMode { timeRange, duration }
enum SessionType { topicStudy, branchTrial }
enum GoalType { hours, questions }

class StudySession {
  final String id;
  final DateTime date;
  final RecordingMode recordingMode;
  final String? startTime;
  final String? endTime;
  final int durationMinutes;
  final SessionType sessionType;
  final String subject;
  final String topic;
  final int correctCount;
  final int wrongCount;
  final int emptyCount;

  StudySession({
    required this.id,
    required this.date,
    required this.recordingMode,
    this.startTime,
    this.endTime,
    required this.durationMinutes,
    required this.sessionType,
    required this.subject,
    required this.topic,
    required this.correctCount,
    required this.wrongCount,
    required this.emptyCount,
  });

  int get totalQuestions => correctCount + wrongCount + emptyCount;

  double get net => correctCount - (wrongCount / 4.0);

  double get wrongRatio =>
      totalQuestions > 0 ? (wrongCount / totalQuestions) : 0.0;

  bool get isHighError => totalQuestions >= 5 && wrongRatio > 0.20;
}

class StudySessionAdapter extends TypeAdapter<StudySession> {
  @override
  final int typeId = 0;

  @override
  StudySession read(BinaryReader reader) {
    final map = Map<String, dynamic>.from(reader.readMap());
    return StudySession(
      id: map['id'] as String,
      date: DateTime.fromMillisecondsSinceEpoch(map['date'] as int),
      recordingMode: RecordingMode.values[map['recordingMode'] as int],
      startTime: map['startTime'] as String?,
      endTime: map['endTime'] as String?,
      durationMinutes: map['durationMinutes'] as int,
      sessionType: SessionType.values[map['sessionType'] as int],
      subject: map['subject'] as String,
      topic: map['topic'] as String,
      correctCount: map['correctCount'] as int,
      wrongCount: map['wrongCount'] as int,
      emptyCount: map['emptyCount'] as int,
    );
  }

  @override
  void write(BinaryWriter writer, StudySession obj) {
    writer.writeMap({
      'id': obj.id,
      'date': obj.date.millisecondsSinceEpoch,
      'recordingMode': obj.recordingMode.index,
      'startTime': obj.startTime,
      'endTime': obj.endTime,
      'durationMinutes': obj.durationMinutes,
      'sessionType': obj.sessionType.index,
      'subject': obj.subject,
      'topic': obj.topic,
      'correctCount': obj.correctCount,
      'wrongCount': obj.wrongCount,
      'emptyCount': obj.emptyCount,
    });
  }
}

class TopicChecklist {
  final String keyId;
  final String subject;
  final String topic;
  final bool isCompleted;
  final bool isManualRedList;
  final bool isClearedFromAutoRedList;

  TopicChecklist({
    required this.keyId,
    required this.subject,
    required this.topic,
    this.isCompleted = false,
    this.isManualRedList = false,
    this.isClearedFromAutoRedList = false,
  });

  TopicChecklist copyWith({
    bool? isCompleted,
    bool? isManualRedList,
    bool? isClearedFromAutoRedList,
  }) {
    return TopicChecklist(
      keyId: keyId,
      subject: subject,
      topic: topic,
      isCompleted: isCompleted ?? this.isCompleted,
      isManualRedList: isManualRedList ?? this.isManualRedList,
      isClearedFromAutoRedList:
          isClearedFromAutoRedList ?? this.isClearedFromAutoRedList,
    );
  }
}

class TopicChecklistAdapter extends TypeAdapter<TopicChecklist> {
  @override
  final int typeId = 1;

  @override
  TopicChecklist read(BinaryReader reader) {
    final map = Map<String, dynamic>.from(reader.readMap());
    return TopicChecklist(
      keyId: map['keyId'] as String,
      subject: map['subject'] as String,
      topic: map['topic'] as String,
      isCompleted: map['isCompleted'] as bool? ?? false,
      isManualRedList: map['isManualRedList'] as bool? ?? false,
      isClearedFromAutoRedList:
          map['isClearedFromAutoRedList'] as bool? ?? false,
    );
  }

  @override
  void write(BinaryWriter writer, TopicChecklist obj) {
    writer.writeMap({
      'keyId': obj.keyId,
      'subject': obj.subject,
      'topic': obj.topic,
      'isCompleted': obj.isCompleted,
      'isManualRedList': obj.isManualRedList,
      'isClearedFromAutoRedList': obj.isClearedFromAutoRedList,
    });
  }
}

class WeeklyGoal {
  final GoalType goalType;
  final int targetValue;
  final int reminderHour;
  final int reminderMinute;

  WeeklyGoal({
    required this.goalType,
    required this.targetValue,
    required this.reminderHour,
    required this.reminderMinute,
  });

  WeeklyGoal copyWith({
    GoalType? goalType,
    int? targetValue,
    int? reminderHour,
    int? reminderMinute,
  }) {
    return WeeklyGoal(
      goalType: goalType ?? this.goalType,
      targetValue: targetValue ?? this.targetValue,
      reminderHour: reminderHour ?? this.reminderHour,
      reminderMinute: reminderMinute ?? this.reminderMinute,
    );
  }
}

class RedListItem {
  final String subject;
  final String topic;
  final int totalQuestions;
  final int totalWrong;
  final double wrongRatio;
  final bool isManual;

  RedListItem({
    required this.subject,
    required this.topic,
    required this.totalQuestions,
    required this.totalWrong,
    required this.wrongRatio,
    required this.isManual,
  });

  String get keyId => '$subject|$topic';
}
